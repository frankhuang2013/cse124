#include <assert.h>
#include "CalcFramer.hpp"

using namespace std;

void CalcFramer::append(string chars)
{
	// PUT YOUR CODE HERE
	str += chars;
	
}

bool CalcFramer::hasMessage() const
{
	// PUT YOUR CODE HERE
	if (str.length() == 0)
		return false;
	else
		return true;
}

string CalcFramer::topMessage() const
{
	// PUT YOUR CODE HERE
	return str.substr(0, str.find_first_of('\n'));
}

void CalcFramer::popMessage()
{
	// PUT YOUR CODE HERE
	str.erase(0, str.find_first_of('\n'));
}

void CalcFramer::printToStream(ostream& stream) const
{
	// (OPTIONAL) PUT YOUR CODE HERE--useful for debugging
}
