#include <assert.h>
#include "CalcFramer.hpp"

using namespace std;

void CalcFramer::append(string chars)
{
	// PUT YOUR CODE HERE
}

bool CalcFramer::hasMessage() const
{
	// PUT YOUR CODE HERE
	return false;
}

string CalcFramer::topMessage() const
{
	// PUT YOUR CODE HERE
	return "";
}

void CalcFramer::popMessage()
{
	// PUT YOUR CODE HERE
}

void CalcFramer::printToStream(ostream& stream) const
{
	// (OPTIONAL) PUT YOUR CODE HERE--useful for debugging
}
